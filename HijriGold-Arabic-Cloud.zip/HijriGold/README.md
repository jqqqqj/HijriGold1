# التقويم الهجري

تطبيق Android مبني من مشروع HijriGold، ومجهز للبناء السحابي من الهاتف عبر GitHub Actions.

## البناء من الجوال

1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات هذا المجلد إلى المستودع.
3. افتح تبويب **Actions**.
4. اختر **Build HijriGold APK**.
5. اضغط **Run workflow**.
6. بعد اكتمال البناء، افتح نتيجة التشغيل وحمّل artifact باسم `HijriGold-debug-apk`.
7. فك الضغط وثبّت ملف `app-debug.apk` على جهاز Android.

## معلومات الإصدار
- اسم التطبيق: التقويم الهجري
- Application ID: com.hijri.gold
- Min SDK: 26
- Target SDK: 34
- الإصدار: 1.0
